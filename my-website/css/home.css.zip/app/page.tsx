export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-zinc-950">
      {/* Main Content Area */}
      <main className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Lantaw</h1>
          <p className="text-zinc-400">Welcome to Lantaw</p>
        </div>
      </main>

      {/* Disclaimer Footer */}
      <footer className="py-4 px-6 bg-zinc-900">
        <p className="text-center text-sm text-zinc-500">
          This site does not store any files on our server, we only linked to the media which is hosted on 3rd party services.
        </p>
      </footer>
    </div>
  )
}
